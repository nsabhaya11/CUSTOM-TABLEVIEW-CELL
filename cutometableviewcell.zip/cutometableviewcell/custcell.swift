//
//  custcell.swift
//  cutometableviewcell
//
//  Created by MACOS on 11/23/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class custcell: UITableViewCell {

    
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var lbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
